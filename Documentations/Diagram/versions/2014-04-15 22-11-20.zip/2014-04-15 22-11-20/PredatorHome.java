/**
 * Write a description of class "PredatorHome" here.
 * 
 * @author     CRHanna
 * @version    07/04/2014 20:15:01
 */
public class PredatorHome extends Home {

	/**
	 * Write a description of this constructor here.
	 * @param origin    a description of the parameter "origin"
	 */
	public PredatorHome(PVector origin, int diameter)
	{
	}

	/**
	 * Write a description of method "display" here.
	 */
	public void display()
	{
	}
}