/**
 * Write a description of class "PherFood" here.
 * 
 * @author     CRHanna
 * @version    05/03/2014 16:19:37
 */
public class PheromoneFood extends Pheromone {

	/** Write a description of field "pherFoodR" here. */
	private final int pherFoodR;

	/** Write a description of field "pherFoodG" here. */
	private final int pherFoodG;

	/** Write a description of field "pherFoodB" here. */
	private final int pherFoodB;

	/** Write a description of field "pherFoodColor" here. */
	public final color pherFoodColor;

	/**
	 * Write a description of this constructor here.
	 */
	public PheromoneFood()
	{
	}

	/**
	 * Write a description of method "display" here.
	 */
	public void display()
	{
	}
}