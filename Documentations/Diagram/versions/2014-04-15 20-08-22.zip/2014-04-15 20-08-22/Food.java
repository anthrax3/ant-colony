/**
 * Write a description of class "Food" here.
 * 
 * @author     CRHanna
 * @version    05/03/2014 15:35:37
 */
public class Food {

	/** Write a description of field "foodR" here. */
	public int foodR;

	/** Write a description of field "foodG" here. */
	public int foodG;

	/** Write a description of field "foodB" here. */
	public int foodB;

	/** Write a description of field "biscuitColor" here. */
	public color biscuitColor;

	/** Write a description of field "sugarColor" here. */
	public int sugarColor;

	/** Write a description of field "toxicColor" here. */
	public boolean toxicColor;

	/** Write a description of field "location" here. */
	public PVector location;

	/**
	 * Write a description of this constructor here.
	 * @param location_    a description of the parameter "location_"
	 */
	public Food(PVector location)
	{
	}

	/**
	 * Write a description of this constructor here.
	 */
	public Food()
	{
	}

	/**
	 * Write a description of method "foodUnit" here.
	 * @param x           a description of the parameter "x       "
	 * @param y           a description of the parameter "y       "
	 * @param wSize       a description of the parameter "wSize   "
	 * @param hSize       a description of the parameter "hSize   "
	 * @param selected       a description of the parameter "hSize   "
	 * @param foodType    a description of the parameter "foodType"
	 */
	public void foodUnit(float x, float y, int wSize, int hSize, boolean selected, int foodType)
	{
	}

	/**
	 * Write a description of method "setFoodColor" here.
	 */
	public void setFoodColor(boolean selected, int foodType)
	{
	}

	/**
	 * Write a description of method "displayFoodUnit" here.
	 */
	public void displayFoodUnit(float x, float y, int wSize, int hSize)
	{
	}

	/**
	 * Write a description of method "displayBiscuit" here.
	 */
	public void displayBiscuit()
	{
	}

	/**
	 * Write a description of method "displaySugar" here.
	 */
	public void displaySugar()
	{
	}

	/**
	 * Write a description of method "displayToxic" here.
	 */
	public void displayToxic()
	{
	}

}