/**
 * Write a description of class "Pher" here.
 * 
 * @author     CRHanna
 * @version    05/03/2014 16:07:56
 */
abstract class Pheromone {

	/** Write a description of field "trail" here. */
	public ArrayList<PVector> trail;

	/** Write a description of field "size" here. */
	public int pheromoneSize;

	/** Write a description of field "location" here. */
	public PVector location;


	/** Write a description of field "lifeSpan" here. */
	public float lifeSpan;

	/**
	 * Write a description of this constructor here.
	 * @param size_    a description of the parameter "size_"
	 */
	public Pheromone(int pheromoneSize)
	{
	}

	/**
	 * Write a description of method "getTrail" here.
	 * @return                a description of the returned result
	 */
	public ArrayList<PVector> getTrail()
	{
	}

	/**
	 * Write a description of method "evaporate" here.
	 */
	public void evaporate()
	{
	}

	/**
	 * Write a description of method "display" here.
	 */
	public void display()
	{
	}

}