/**
 * Write a description of class "PherHome" here.
 * 
 * @author     CRHanna
 * @version    05/03/2014 16:20:15
 */
public class PheromoneHome extends Pheromone {

	/** Write a description of field "pherHomeR" here. */
	private final int pherHomeR;

	/** Write a description of field "pherHomeG" here. */
	private final int pherHomeG;

	/** Write a description of field "pherHomeB" here. */
	private final int pherHomeB;

	/** Write a description of field "pherHomeColor" here. */
	public final int pherHomeColor;

	/**
	 * Write a description of this constructor here.
	 * @param size_    a description of the parameter "size_"
	 */
	public PheromoneHome(int size_)
	{
	}

	/**
	 * Write a description of method "display" here.
	 */
	public void display()
	{
	}
}