/**
 * Write a description of class "Ant" here.
 * 
 * @author     CRHanna
 * @version    05/03/2014 15:04:21
 */
public class Ant {

	/** the x and y position of the ant. */
	private PVector location;

	/** pushes the ant into moving the location. */
	private PVector velocity;

	/** pushes the ant into speeding the velocity. */
	private PVector acceleration;

	/** the width of the ant. */
	private final float wSize;

	/** the height of the ant. */
	private final float hSize;

	/** the area size of the - width*height. */
	private final float antSize;

	/** the maximum speed that the ant can move. */
	private float maxSpeed;

	/** the minimum speed that the ant can move. */
	private float minSpeed;

	/** the maximum steering force of the ant. */
	private float maxForce;

	/** the directional angle of the ant's movement. */
	private final float head;

	/** the angle that determine the ant's wandering behavior. */
	private float wandertheta;

	/** the ant's mass. */
	private final float mass;

	/** the ant's Red channel variable. */
	private final int antR;

	/** the ant's Green channel variable. */
	private final int antG;

	/** the ant's Blue channel variable. */
	private final int antB;

	/** The color of the ant - the 3 channels combined. */
	private final color antColor;

	/** stores the the opacity of the ant's color
	* that can be decremented to make the ant disappear. */
	private int lifeSpan;

	/** sets the borders of the window. */
	private final int border;

	/** Write a description of field "ph" here. */
	private ArrayList<PVector> homeTrail;

	/** Write a description of field "pf" here. */
	private ArrayList<PVector> foodTrail;

	/** Write a description of field "pf" here. */
	private ArrayList<PVector> toxicTrail;

	/** Write a description of field "antTrapped" here. */
	private boolean attackPredator;
	
	/** Write a description of field "antTrapped" here. */
	private boolean antTrapped;

	/** Write a description of field "antTrapped" here. */
	private boolean hasFood;

	/** Write a description of field "antTrapped" here. */
	private boolean hasBiscuit;

	/** Write a description of field "antTrapped" here. */
	private boolean hasSugar;

	/** Write a description of field "antTrapped" here. */
	private boolean hasToxic;

	/** Write a description of field "intoxicated" here. */
	private boolean intoxicated;

	/** Write a description of field "intoxicated" here. */
	private boolean isToxic;

	/** Write a description of field "h" here. */
	public Home h;

	

	

	/**
	 * Write a description of this constructor here.
	 */
	public Ant(PVector location, ArrayList<PVector>homeTrail, ArrayList<PVector>foodTrail, ArrayList<PVector>toxicTrail)
	{
	}

	/**
	 * Write a description of this constructor here.
	 */
	public Ant(PVector location)
	{
	}

	/**
	 * Write a description of method "update" here.
	 */
	public void update()
	{
	}

	/**
	 * Write a description of method "applyForce" here.
	 */
	public void applyForce(PVector force)
	{
	}

	/**
	 * Write a description of method "applyForce" here.
	 */
	public void addHomePheromone()
	{
	}

	/**
	 * Write a description of method "applyForce" here.
	 */
	public void addFoodPheromone()
	{
	}

	/**
	 * Write a description of method "applyForce" here.
	 */
	public void addToxicPheromone()
	{
	}

	/**
	 * Write a description of method "wander" here.
	 */
	public void wander()
	{
	}

	/**
	 * Write a description of method "seek" here.
	 */
	public void seek(PVector target)
	{
	}

	/**
	 * Write a description of method "seek" here.
	 */
	public void fleePredator(Predator p)
	{
	}

	/**
	 * Write a description of method "seek" here.
	 */
	public boolean attackPredator()
	{
	}

	/**
	 * Write a description of method "seek" here.
	 */
	public void attackPredator(Predator p, ArrayList<Ant> ants)
	{
	}

	/**
	 * Write a description of method "seek" here.
	 */
	public void antTrapped(Home ph)
	{
	}

	/**
	 * Write a description of method "seek" here.
	 */
	public boolean antTrapped() 
	{
	}

	/**
	 * Write a description of method "findFood" here.
	 */
	public void findFoodPheromone(FoodSource biscuit, FoodSource sugar, FoodSource toxic)
	{
	}

	/**
	 * Write a description of method "findFood" here.
	 */
	public void findHomePheromone(Home h)
	{
	}

	/**
	 * Write a description of method "findFood" here.
	 */
	public void findToxicPheromone()
	{
	}

	/**
	 * Write a description of method "findFood" here.
	 */
	public boolean hasFood()
	{
	}

	/**
	 * Write a description of method "findFood" here.
	 */
	public boolean hasBiscuit()
	{
	}

	/**
	 * Write a description of method "findFood" here.
	 */
	public boolean hasSugar()
	{
	}

	/**
	 * Write a description of method "findFood" here.
	 */
	public boolean hasToxic()
	{
	}

	/**
	 * Write a description of method "findFood" here.
	 */
	public void findFood(FoodSource biscuit, FoodSource sugar, FoodSource toxic, boolean isToxicFood)
	{
	}

	/**
	 * Write a description of method "findFood" here.
	 */
	public void foodDelivery(Home h)
	{
	}

	/**
	 * Write a description of method "findFood" here.
	 */
	public void die()
	{
	}

	/**
	 * Write a description of method "findFood" here.
	 */
	public boolean isIntoxicated()
	{
	}

	/**
	 * Write a description of method "arrive" here.
	 * @param target    a description of the parameter "target"
	 */
	public void arrive(PVector target)
	{
	}

	/**
	 * Write a description of method "reachHome" here.
	 * @param h    a description of the parameter "h"
	 * @return                a description of the returned result
	 */
	public boolean reachHome(Home h)
	{
	}

	/**
	 * Write a description of method "display" here.
	 */
	public void displayCarriedFood()
	{
	}
	
	/**
	 * Write a description of method "display" here.
	 */
	public void display()
	{
	}

	/**
	 * Write a description of method "displayAntIcon" here.
	 * @param x        a description of the parameter "x    "
	 * @param y        a description of the parameter "y    "
	 * @param value    a description of the parameter "value"
	 */
	public void displayAntIcon(float x, float y, int value)
	{
	}

	/**
	 * Write a description of method "findFood" here.
	 */
	public int setLifeSpan(int value)
	{
	}

	/**
	 * Write a description of method "displayAnt" here.
	 * @param c           a description of the parameter "c       "
	 * @param lifeSpan    a description of the parameter "lifeSpan"
	 * @param rotation    a description of the parameter "rotation"
	 * @param r1          a description of the parameter "r1      "
	 * @param r2          a description of the parameter "r2      "
	 * @param r3          a description of the parameter "r3      "
	 */
	public void displayAnt(color c, int lifeSpan, float rotation, float r1, float r2, float r3)
	{
	}

	/**
	 * Write a description of method "checkEdges" here.
	 */
	public void checkEdges()
	{
	}

	
}