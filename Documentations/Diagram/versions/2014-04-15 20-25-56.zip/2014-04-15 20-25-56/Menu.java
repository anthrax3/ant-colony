/**
 * Write a description of class "Menu" here.
 * 
 * @author     CRHanna
 * @version    05/03/2014 19:25:28
 */
public class Menu {

	/** Write a description of field "location" here. */
	private PVector location;

	/** Write a description of field "wSize" here. */
	private int wSize;

	/** Write a description of field "hSize" here. */
	private int hSize;

	/** Write a description of field "alpha1" here. */
	private int alpha1;

	/** Write a description of field "alpha2" here. */
	private int alpha2;

	/** Write a description of field "alpha3" here. */
	private int alpha3;

	/** Write a description of field "typeCount" here. */
	private int typeCount;

	/** Write a description of field "typeCount" here. */
	private int value;

	/** Write a description of field "yPosition" here. */
	private float yPosition;

	/** Write a description of field "counter" here. */
	private int counter;

	/** Write a description of field "selectBiscuit" here. */
	private boolean selectBiscuit;

	/** Write a description of field "selectSugar" here. */
	private boolean selectSugar;

	/** Write a description of field "selectToxic" here. */
	private boolean selectToxic;

	/** Write a description of field "selected" here. */
	private boolean selected;

	/** Write a description of field "showPredator" here. */
	private boolean showPredator;

	/** Write a description of field "predatorPressed" here. */
	private boolean predatorPressed;

	/** Write a description of field "antPressed" here. */
	private boolean antPressed;

/** Write a description of field "antPressed" here. */
	private boolean resetPressed;

	/** Write a description of field "letter" here. */
	private char letter;

	/** Write a description of field "p" here. */
	private Predator predator;
	
	/** Write a description of field "c" here. */
	private Colony colony;

	/** Write a description of field "a" here. */
	private Ant ant;

	/** Write a description of field "food" here. */
	private Food food;

	/**
	 * Write a description of this constructor here.
	 */
	public Menu(PVector location, Predator predator, Colony colony)
	{
	}

	/**
	 * Write a description of method "reset" here.
	 */
	public void reset()
	{
	}

	/**
	 * Write a description of method "displayPredator" here.
	 */
	public void displayPredator()
	{
	}

	/**
	 * Write a description of method "displayAnt" here.
	 */
	public void displayAnt()
	{
	}

	/**
	 * Write a description of method "displayFoodMenu" here.
	 * @param f    a description of the parameter "f"
	 */
	public void displayFoodMenu(FoodSource f)
	{
	}

	/**
	 * Write a description of method "addFoodFromMenu" here.
	 */
	public void addBiscuitFromMenu(float x, float y, FoodSource f)
	{
	}

	/**
	 * Write a description of method "addFoodFromMenu" here.
	 */
	public void addSugarFromMenu(float x, float y, FoodSource f)
	{
	}

	/**
	 * Write a description of method "addFoodFromMenu" here.
	 */
	public void addToxicFromMenu(float x, float y, FoodSource f)
	{
	}

	/**
	 * Write a description of method "setConditions" here.
	 */
	public void setToggleConditions()
	{
	}

	/**
	 * Write a description of method "getFoodColor" here.
	 */
	public void getBiscuitColor()
	{
	}

	/**
	 * Write a description of method "getFoodColor" here.
	 */
	public void getSugarColor()
	{
	}

	/**
	 * Write a description of method "getFoodColor" here.
	 */
	public void getToxicColor()
	{
	}


	/**
	 * Write a description of method "mousePressed" here.
	 */
	public void mousePressed(float x, float y, FoodSource biscuit, FoodSource sugar, FoodSource toxic)
	{
	}

	/**
	 * Write a description of method "showPredator" here.
	 * @return                a description of the returned result
	 */
	public boolean addAnt()
	{
	}
	
	/**
	 * Write a description of method "showPredator" here.
	 * @return                a description of the returned result
	 */
	public boolean showPredator()
	{
	}

	/**
	 * Write a description of method "hidePredator" here.
	 * @return                a description of the returned result
	 */
	public boolean hidePredator()
	{
	}

	/**
	 * Write a description of method "displayBar" here.
	 */
	public void displayBar()
	{
	}

}