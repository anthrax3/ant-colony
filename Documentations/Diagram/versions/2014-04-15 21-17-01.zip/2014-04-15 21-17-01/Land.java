/**
 * Write a description of class "Land" here.
 * 
 * @author     CRHanna
 * @version    05/03/2014 16:02:53
 */
public class Land {

/** Write a description of field "backgroundColor" here. */
	private final color backgroundColor;
	
	/** Write a description of field "landR" here. */
	private final int landR;

	/** Write a description of field "landG" here. */
	private final int landG;

	/** Write a description of field "landB" here. */
	private final int landB;

	/** Write a description of field "location" here. */
	private PVector location;

	/** Write a description of field "wSize" here. */
	private final int wSize;

	/** Write a description of field "hSize" here. */
	private final int hSize;

	/** Write a description of field "size" here. */
	private final int size;

	/** Write a description of field "increment" here. */
	private float increment;

	/**
	 * Write a description of this constructor here.
	 */
	public Land()
	{
	}

	/**
	 * Write a description of method "displaySoil" here.
	 */
	public void displayLand()
	{
	}

	/**
	 * Write a description of method "texture" here.
	 */
	public void texture()
	{
	}
}