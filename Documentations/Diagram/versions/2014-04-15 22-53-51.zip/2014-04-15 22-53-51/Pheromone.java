/**
 * this class is amaster class for the two subclasses PherFood and PherHome
 this class is responsible for drawing the pheremone trails behind the ant
 it should also remembers origin and destination it traveled so that ican 
 serve as a guide to other ants to follow
 * 
 * @author     CRHanna
 * @version    05/03/2014 16:07:56
 */
abstract class Pheromone {

	/** instatiation of the trail as an arrylist of type PVector. */
	public ArrayList<PVector> trail;

	/** the size of the trail. */
	public int pheromoneSize;

	/** the location vector of the trail */
	public PVector location;

	/** the opacity of the trail that can be decremented in order to make the pheromones evaporate. */
	public float lifeSpan;

	/**
	 * Write a description of this constructor here.
	 * @param size_    a description of the parameter "size_"
	 */
	public Pheromone(int pheromoneSize)
	{
	}

	/**
	 * Write a description of method "getTrail" here.
	 * @return                a description of the returned result
	 */
	public ArrayList<PVector> getTrail()
	{
	}

	/**
	 * Write a description of method "evaporate" here.
	 */
	public void evaporate()
	{
	}

	/**
	 * Write a description of method "display" here.
	 */
	public void display()
	{
	}

}