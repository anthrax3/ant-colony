/**
 * this class manages the food particle
 it places it inside an ArrayList forming a grid
 The grid is the food that the ant will eat from
 * 
 * @author     CRHanna
 * @version    05/03/2014 16:33:53
 */
public class FoodSource {

	/** arraylist grid of type Food */
	public ArrayList<Food> grid;

	/** location vector */
	private PVector location;

	/** rows of the grid */
	private final int rows;

	/** columns of the grid */
	private final int cols;

	/** width of a particle inside the grid. */
	private final int unitW;

	/** width of a particle inside the grid. */
	private final int unitH;

	/** the area size of the unit. */
	private final int unitSize;

	/** keep track of how many ants accessed the eatFood()
	and decrement the number of particles in the arraylist accordingly. */
	private int counter;

	/** Write a description of field "hasParticle" here. */
	private boolean hasParticle;

	/** Write a description of field "addFood" here. */
	private boolean addFood;

	/** Write a description of field "foodStatus" here. */
	private boolean foodStatus;

	/**
	 * Write a description of this constructor here.
	 * @param location_    a description of the parameter "location_"
	 * @param gridSize     a description of the parameter "gridSize "
	 */
	public FoodSource(PVector location, int gridSize)
	{
	}

/**
	 * Write a description of method "setGrid" here.
	 */
	public void setGrid()
	{
	}

	/**
	 * Write a description of method "addFood" here.
	 */
	public boolean noFood() 
	{
	}
	
	/**
	 * Write a description of method "getFoodStatus" here.
	 * @return                a description of the returned result
	 */
	public boolean getFoodStatus(boolean status)
	{
	}

	/**
	 * Write a description of method "setFoodStatus" here.
	 * @return                a description of the returned result
	 */
	public boolean setFoodStatus()
	{
	}

	/**
	 * Write a description of method "addFood" here.
	 */
	public void addBiscuit()
	{
	}

	/**
	 * Write a description of method "addFood" here.
	 */
	public void addSugar()
	{
	}

	/**
	 * Write a description of method "addFood" here.
	 */
	public void addToxic()
	{
	}

	/**
	 * Write a description of method "addFoodIcon" here.
	 */
	public void addFoodIcon(float x, float y, int size, boolean selected, int type)
	{
	}

	/**
	 * Write a description of method "setSelected" here.
	 * @param selected    a description of the parameter "selected"
	 * @return                a description of the returned result
	 */
	public boolean setSelected(boolean selected)
	{
	}

	/**
	 * Write a description of method "hasParticle" here.
	 * @return                a description of the returned result
	 */
	public boolean hasParticle()
	{
	}

	/**
	 * Write a description of method "eatFood" here.
	 * @param l    a description of the parameter "l"
	 * @param h    a description of the parameter "h"
	 */
	public void eatFood(PVector l)
	{
	}
}