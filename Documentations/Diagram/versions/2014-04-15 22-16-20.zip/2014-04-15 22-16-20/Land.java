/**
 * Write a description of class "Land" here.
 * 
 * @author     CRHanna
 * @version    05/03/2014 16:02:53
 */
public class Land {

/** the location vector. */
	private final color backgroundColor;
	
	/** Red channel of the land. */
	private final int landR;

	/** Green channel of the land. */
	private final int landG;

	/** Blue channel of the land. */
	private final int landB;

	/** Write a description of field "wSize" here. */
	private final int wSize;

	/** Write a description of field "hSize" here. */
	private final int hSize;

	/** Write a description of field "size" here. */
	private final int size;

	/** Write a description of field "increment" here. */
	private float increment;

	/**
	 * Write a description of this constructor here.
	 */
	public Land()
	{
	}

	/**
	 * Write a description of method "displaySoil" here.
	 */
	public void displayLand()
	{
	}

	/**
	 * Write a description of method "texture" here.
	 */
	public void texture()
	{
	}
}