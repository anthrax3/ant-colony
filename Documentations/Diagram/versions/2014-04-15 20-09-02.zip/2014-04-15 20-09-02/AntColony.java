/**
 * Write a description of class "AntColony" here.
 * 
 * @author     CRHanna
 * @version    05/03/2014 16:28:45
 */
public class AntColony {

	/** Write a description of field "h" here. */
	public Home antHome;
	
	/** Write a description of field "predatorHome" here. */
	public PredatorHome predatorHome;

	/** Write a description of field "l" here. */
	public Land land;

	/** Write a description of field "c" here. */
	public Colony colony;

	/** Write a description of field "Predator" here. */
	public Predator predator;

	/** Write a description of field "f" here. */
	public FoodSource biscuit;

	/** Write a description of field "f" here. */
	public FoodSource sugar;

	/** Write a description of field "f" here. */
	public FoodSource toxic;

	/** Write a description of field "Menu" here. */
	public Menu menu;

	

	/**
	 * Write a description of method "setup" here.
	 */
	public void setup()
	{
	}

	/**
	 * Write a description of method "draw" here.
	 */
	public void draw()
	{
	}

	/**
	 * Write a description of method "mousePressed" here.
	 */
	public void mousePressed()
	{
	}
}