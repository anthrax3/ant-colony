/**
 * Write a description of class "FoodGrid" here.
 * 
 * @author     CRHanna
 * @version    05/03/2014 16:33:53
 */
public class FoodSource {

	/** Write a description of field "grid" here. */
	public ArrayList<Food> grid;

	/** Write a description of field "location" here. */
	private PVector location;

	/** Write a description of field "rows" here. */
	private final int rows;

	/** Write a description of field "cols" here. */
	private final int cols;

	/** Write a description of field "unitW" here. */
	private final int unitW;

	/** Write a description of field "unitH" here. */
	private final int unitH;

	/** Write a description of field "unitSize" here. */
	private final int unitSize;

	/** Write a description of field "counter" here. */
	private int counter;

	/** Write a description of field "hasParticle" here. */
	private boolean hasParticle;

	/** Write a description of field "addFood" here. */
	private boolean addFood;

	/** Write a description of field "foodStatus" here. */
	private boolean foodStatus;

	/**
	 * Write a description of this constructor here.
	 * @param location_    a description of the parameter "location_"
	 * @param gridSize     a description of the parameter "gridSize "
	 */
	public FoodSource(PVector location, int gridSize)
	{
	}

/**
	 * Write a description of method "setGrid" here.
	 */
	public void setGrid()
	{
	}

	/**
	 * Write a description of method "addFood" here.
	 */
	public boolean noFood() 
	{
	}
	
	/**
	 * Write a description of method "getFoodStatus" here.
	 * @return                a description of the returned result
	 */
	public boolean getFoodStatus(boolean status)
	{
	}

	/**
	 * Write a description of method "setFoodStatus" here.
	 * @return                a description of the returned result
	 */
	public boolean setFoodStatus()
	{
	}

	/**
	 * Write a description of method "addFood" here.
	 */
	public void addBiscuit()
	{
	}

	/**
	 * Write a description of method "addFood" here.
	 */
	public void addSugar()
	{
	}

	/**
	 * Write a description of method "addFood" here.
	 */
	public void addToxic()
	{
	}

	/**
	 * Write a description of method "addFoodIcon" here.
	 */
	public void addFoodIcon(float x, float y, int size, boolean selected, int type)
	{
	}

	/**
	 * Write a description of method "setSelected" here.
	 * @param selected    a description of the parameter "selected"
	 * @return                a description of the returned result
	 */
	public boolean setSelected(boolean selected)
	{
	}

	/**
	 * Write a description of method "hasParticle" here.
	 * @return                a description of the returned result
	 */
	public boolean hasParticle()
	{
	}

	/**
	 * Write a description of method "eatFood" here.
	 * @param l    a description of the parameter "l"
	 * @param h    a description of the parameter "h"
	 */
	public void eatFood(PVector l)
	{
	}
}