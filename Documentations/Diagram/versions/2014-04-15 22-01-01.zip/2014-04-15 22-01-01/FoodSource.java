/**
 * this class manages the food particle
 it places it inside an ArrayList forming a grid
 The grid is the food that the ant will eat from
 * 
 * @author     CRHanna
 * @version    05/03/2014 16:33:53
 */
public class FoodSource {

	/** arraylist grid of type Food */
	public ArrayList<Food> grid;

	/** location vector */
	private PVector location;

	/** rows of the grid */
	private final int rows;

	/** columns of the grid */
	private final int cols;

	/** width of a particle inside the grid. */
	private final int unitW;

	/** width of a particle inside the grid. */
	private final int unitH;

	/** the area size of the unit. */
	private final int unitSize;

	/** keep track of how many ants accessed the eatFood()
	and decrement the number of particles in the arraylist accordingly. */
	private int counter;

	/** checks whether the ant has reached to the food. */
	private boolean hasParticle;

	/** check if the food is selected from the menu. */
	private boolean addFood;

	/** pass the status of adding or not adding food to the
	addBiscuit(), addSugar(), and addToxic() methods. */
	private boolean foodStatus;

	/**
	 * @param location    	is used to position  the arraylist across the window
	 * @param gridSize     	specifies the number of rows and columns of the grid. the amount is the same for both
	 * 					because grid should always remain square		
	 */
	public FoodSource(PVector location, int gridSize)
	{
	}

/**
	 * Write a description of method "setGrid" here.
	 */
	public void setGrid()
	{
	}

	/**
	 * Write a description of method "addFood" here.
	 */
	public boolean noFood() 
	{
	}
	
	/**
	 * Write a description of method "getFoodStatus" here.
	 * @return                a description of the returned result
	 */
	public boolean getFoodStatus(boolean status)
	{
	}

	/**
	 * Write a description of method "setFoodStatus" here.
	 * @return                a description of the returned result
	 */
	public boolean setFoodStatus()
	{
	}

	/**
	 * Write a description of method "addFood" here.
	 */
	public void addBiscuit()
	{
	}

	/**
	 * Write a description of method "addFood" here.
	 */
	public void addSugar()
	{
	}

	/**
	 * Write a description of method "addFood" here.
	 */
	public void addToxic()
	{
	}

	/**
	 * Write a description of method "addFoodIcon" here.
	 */
	public void addFoodIcon(float x, float y, int size, boolean selected, int type)
	{
	}

	/**
	 * Write a description of method "setSelected" here.
	 * @param selected    a description of the parameter "selected"
	 * @return                a description of the returned result
	 */
	public boolean setSelected(boolean selected)
	{
	}

	/**
	 * Write a description of method "hasParticle" here.
	 * @return                a description of the returned result
	 */
	public boolean hasParticle()
	{
	}

	/**
	 * Write a description of method "eatFood" here.
	 * @param l    a description of the parameter "l"
	 * @param h    a description of the parameter "h"
	 */
	public void eatFood(PVector l)
	{
	}
}