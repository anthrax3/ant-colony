/**
 * Write a description of class "Colony" here.
 * 
 * @author     CRHanna
 * @version    05/03/2014 15:23:03
 */
public class Colony{

	/** Write a description of field "ants" here. */
	public ArrayList<Ant> ants;

	/** Write a description of field "location" here. */
	private PVector location;

	/** Write a description of field "antNum" here. */
	private final int antNum;

	/** Write a description of field "h" here. */
	public Home antHome;

	/** Write a description of field "predatorHome" here. */
	private PredatorHome predatorHome;

	/** Write a description of field "p" here. */
	private Predator predator;

	/** Write a description of field "ph" here. */
	private Pheromone pheromoneHome;

	/** Write a description of field "pf" here. */
	private Pheromone pheromoneFood;

	/** Write a description of field "pf" here. */
	private Pheromone pheromoneToxic;

	/** Write a description of field "ant" here. */
	public Ant ant;

	/** Write a description of field "ant" here. */
	public Food foodParticle;

	/** Write a description of field "changePheromoneColor" here. */
	private boolean isToxicFood;

	/**
	 * Write a description of this constructor here.
	 */
	public Colony(Home antHome, Predator predator, Home predatorHome)
	{
	}

	/**
	 * Write a description of method "addAnt" here.
	 * @param num    a description of the parameter "num"
	 */
	public void addAnt(int num)
	{
	}

	/**
	 * Write a description of method "getAnts" here.
	 * @return                a description of the returned result
	 */
	public ArrayList<Ant> getAnts()
	{
	}

	

	/**
	 * Write a description of method "eatenByPredator" here.
	 * @param p    a description of the parameter "p"
	 */
	public void eatenByPredator(Predator p)
	{
	}

	/**
	 * Write a description of method "eatenByPredator" here.
	 */
	public void addAnt(Menu m)
	{
	}

	/**
	 * Write a description of method "displayColony" here.
	 */
	public void displayColony(Menu m)
	{
	}

	/**
	 * Write a description of method "run" here.
	 * @param menu       a description of the parameter "menu   "
	 * @param biscuit    a description of the parameter "biscuit"
	 * @param sugar      a description of the parameter "sugar  "
	 * @param toxic      a description of the parameter "toxic  "
	 */
	public void run(Menu menu, FoodSource biscuit, FoodSource sugar, FoodSource toxic)
	{
	}
}