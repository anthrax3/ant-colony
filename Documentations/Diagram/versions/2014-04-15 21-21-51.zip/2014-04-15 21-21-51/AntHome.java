/**
 * Write a description of class "AntHome" here.
 * 
 * @author     CRHanna
 * @version    15/04/2014 18:30:46
 */
public class AntHome extends Home {

	/**
	 * Write a description of this constructor here.
	 * @param origin      a description of the parameter "origin  "
	 * @param diameter    a description of the parameter "diameter"
	 */
	public AntHome(PVector origin, int diameter)
	{
	}

	/**
	 * Write a description of method "display" here.
	 */
	public void display()
	{
	}
}