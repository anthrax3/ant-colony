/**
 * Write a description of class "PheromoneToxic" here.
 * 
 * @author     CRHanna
 * @version    15/04/2014 19:12:13
 */
public class PheromoneToxic extends Pheromone {

	/** Write a description of field "pherToxicR" here. */
	private final int pherToxicR;

	/** Write a description of field "pherToxicG" here. */
	private final int pherToxicG;

	/** Write a description of field "pherToxicB" here. */
	private final int pherToxicB;

	/** Write a description of field "pherToxicColor" here. */
	private final color pherToxicColor;

	/**
	 * Write a description of this constructor here.
	 * @param size    a description of the parameter "size"
	 */
	public PheromoneToxic(int size)
	{
	}

	/**
	 * Write a description of method "display" here.
	 */
	public void display()
	{
	}
}