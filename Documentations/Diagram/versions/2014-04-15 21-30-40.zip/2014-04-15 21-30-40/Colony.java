/**
 * Write a description of class "Colony" here.
 * 
 * @author     CRHanna
 * @version    05/03/2014 15:23:03
 */
public class Colony{

	/** instantiation of ants as an arraylist of type Ant. */
	public ArrayList<Ant> ants;

	/** declares a PVector location. */
	private PVector location;

	/** manages the number of ants. */
	private final int antNum;

	/** instance of the Home of the ant. */
	public Home antHome;

	/** instance the home of the Predator. */
	private PredatorHome predatorHome;

	/** instance of type Predator. */
	private Predator predator;

	/** instance of type PheromoneHome. */
	private Pheromone pheromoneHome;

	/** instance of type PheromoneFood. */
	private Pheromone pheromoneFood;

	/** instance of type PheromoneToxic. */
	private Pheromone pheromoneToxic;

	/** instance of type Ant. */
	public Ant ant;

	/** instance of type Food. */
	public Food foodParticle;

	/** checks whether the food is toxic. */
	private boolean isToxicFood;

	/**
	 * Write a description of this constructor here.
	 */
	public Colony(Home antHome, Predator predator, Home predatorHome)
	{
	}

	/**
	 * Write a description of method "addAnt" here.
	 * @param num    a description of the parameter "num"
	 */
	public void addAnt(int num)
	{
	}

	/**
	 * Write a description of method "getAnts" here.
	 * @return                a description of the returned result
	 */
	public ArrayList<Ant> getAnts()
	{
	}

	

	/**
	 * Write a description of method "eatenByPredator" here.
	 * @param p    a description of the parameter "p"
	 */
	public void eatenByPredator(Predator p)
	{
	}

	/**
	 * Write a description of method "eatenByPredator" here.
	 */
	public void addAnt(Menu m)
	{
	}

	/**
	 * Write a description of method "displayColony" here.
	 */
	public void displayColony(Menu m)
	{
	}

	/**
	 * Write a description of method "run" here.
	 * @param menu       a description of the parameter "menu   "
	 * @param biscuit    a description of the parameter "biscuit"
	 * @param sugar      a description of the parameter "sugar  "
	 * @param toxic      a description of the parameter "toxic  "
	 */
	public void run(Menu menu, FoodSource biscuit, FoodSource sugar, FoodSource toxic)
	{
	}
}