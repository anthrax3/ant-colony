/**
 * Write a description of class "displayToxic" here.
 * 
 * @author     CRHanna
 * @version    05/03/2014 15:50:14
 */
 private abstract class Home {

	/** Write a description of field "origin" here. */
	public PVector origin;

	/** Write a description of field "diameter" here. */
	private final int diameter;

	/**
	 * Write a description of this constructor here.
	 * @param origin_    a description of the parameter "origin_"
	 */
	public Home(PVector origin, int diameter)
	{
	}

	/**
	 * Write a description of method "getDiameter" here.
	 * @return                a description of the returned result
	 */
	public int getDiameter()
	{
	}

	/**
	 * Write a description of method "display" here.
	 */
	public void display()
	{
	}
}